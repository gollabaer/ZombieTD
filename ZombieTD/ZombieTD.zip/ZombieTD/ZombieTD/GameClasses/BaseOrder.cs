﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace ZombieTD
{
    public class BaseOrder : IOrder
    {
        public  SpawnType Type{ get; set; }
        public int X { get; set; }
        public int Y { get; set; }
    }
}
