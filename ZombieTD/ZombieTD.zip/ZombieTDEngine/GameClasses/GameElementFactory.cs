using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ZombieTDEngine.GameInterfaces;

namespace ZombieTDEngine.GameClasses
{
    class GameElementFactory
    {
        public IGameElement MakeZombie()
        {
            return null;
        }

        public IGameElement MakeZombieDog()
        {
            return null;
        }

        public IGameElement MakeFlyingZombie()
        {
            return null;
        }

        public IGameElement MakeRedneck()
        {
            return null;
        }

        public IGameElement MakeSheriff()
        {
            return null;
        }

        public IGameElement MakePriest()
        {
            return null;
        }

        public IGameElement MakeHay()
        {
            return null;
        }

        public IGameElement MakeCar()
        {
            return null;
        }

        public IGameElement MakePit()
        {
            return null;
        }
    }
}
