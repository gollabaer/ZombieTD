﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ZombieTDEngine
{
    public class Map
    {
        List<Tile> _tiles;

        public Map GetMapByLineOfSight(int lineOfSight, int x, int y)
        {
            return new Map();
        }
    }
}
