﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ZombieTDEngine
{
    public class Sheriff : Character, ISheriff
    {
        public override void TakeTurn(IMediator mediator)
        {
            base.TakeTurn(mediator);
            //Game logic for what a zombie does
            


        }

        public void FireGun(IMediator mediator, ICharacter character, ICharacter target)
        {

        }
    }
}
