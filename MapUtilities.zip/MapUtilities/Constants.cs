﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MapUtilities
{
    public static class Constants
    {

    }

    public enum MapTileType
    {
        RoadOutside,
        Building_roof_center,
        Building_roof_corner,
        Building_Roof_Side,
        Grass,
        Path_noRock,
        Path_withRock,
        Path_Corner,
        RoadMiddle,
        RoofTownHall_corner,
        TownHallRoof_Middle,
        TownhallRoof_Side,
        Tree,
        Error

    } 
}
