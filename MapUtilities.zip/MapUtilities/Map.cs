﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MapUtilities
{
    public class Map
    {
        public List<Tile> Tiles { get; set; }

        public void Draw()
        {
            
        }

        public Map GetMapByLineOfSight(int lineOfSight, int x, int y)
        {
            return new Map();
        }

        //public static Map LoadMap
    }
}
