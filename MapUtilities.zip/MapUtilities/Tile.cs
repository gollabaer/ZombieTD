﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace MapUtilities
{
    public class Tile
    {
      
        PictureBox _picture;

        MapTileType _textureType;

        int _number_of_90_degree_flips;

        int _xPos;
        int _yPos;

        [XmlIgnore()] 
        public PictureBox Picture
        {
            get { return _picture; }
            set { _picture = value; }

        }

        public MapTileType TextureType
        {
            get { return _textureType; }
            set { _textureType = value; }

        }

        public int Xpos
        {
            get { return _xPos; }
            set { _xPos = value; }

        }

        public int Ypos
        {
            get { return _yPos; }
            set { _yPos = value; }

        }

        public int Flips
        {
            get { return _number_of_90_degree_flips; }
            set { _number_of_90_degree_flips = value; }
        }
        
        public void FlipCountAdd()
        {
            if (_number_of_90_degree_flips == 3)
            {
                _number_of_90_degree_flips = -1;
            }

            _number_of_90_degree_flips++;
        }
    }



} 
