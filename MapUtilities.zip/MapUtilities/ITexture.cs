using System;
using System.Collections.Generic;
using System.Linq;



namespace ZombieTD
{
    /// <summary>
    /// This is a game component that implements IUpdateable.
    /// </summary>
    public interface ITexture 
    {
         


    }
}
