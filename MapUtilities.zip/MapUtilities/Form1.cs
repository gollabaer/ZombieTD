﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace MapUtilities
{
    public partial class Form1 : Form
    {
        private Random random = new Random();

        const int _mapX = 40;
        const int _mapY = 22;
        const int _tileX = 32;
        const int _tileY = 32;



        List<Tile> _tiles = new List<Tile>();
        MapTileType _currentType = MapTileType.Grass;


        Map _map = new Map();


        bool border = true;


   
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            _tiles = CreateTiles(_mapX, _mapY, _tileX, _tileY);
         
            foreach(Tile tile in _tiles)
            {
                this.Controls.Add(tile.Picture);
           
           }


            CreateToolbox();
        }

        private void CreateToolbox()
        {
            Array values = Enum.GetValues(typeof(MapTileType));
            int x =0;
            int y =0;

            foreach (MapTileType tileType in values)
            {
                PictureBox pictureBox = new PictureBox();

                pictureBox.Image = Image.FromFile(tileType.ToString().Png());
                pictureBox.Height = 32;
                pictureBox.Width = 32;
                pictureBox.Location = (new Point(x,y  ));
                pictureBox.BorderStyle = BorderStyle.FixedSingle;
                pictureBox.Tag = tileType;
                pictureBox.Click += new System.EventHandler(this.Control_Click);
                grpControls.Controls.Add(pictureBox);
                x += 32;
            }


        }
        private List<Tile> CreateTiles(int xSize, int ySize, int tileXSize, int tileYSize)
        {
            int xpos = 0;
            int ypos = 0;
            List<Tile> tiles = new List<Tile>();
            Image ErrorTile = Image.FromFile((MapTileType.Error.ToString()).Png() );
            

            for (int i = 0; i < ySize; i++)
            {

                for (int i2 = 0; i2 < xSize; i2++)
                {
                    Tile tile = new Tile();
                    PictureBox pictureBox = new PictureBox();
                    ErrorTile = RandomRotate(ErrorTile);
                    tile.Xpos = xpos;
                    tile.Ypos = ypos;
                    tile.TextureType = MapTileType.Error;
                    pictureBox.Location = (new Point(xpos, ypos));
                    pictureBox.Image = (Image)ErrorTile.Clone();
                    pictureBox.Height = tileYSize;
                    pictureBox.Width = tileXSize;
                    pictureBox.BorderStyle = BorderStyle.FixedSingle;
                    pictureBox.Tag = tile;
                    pictureBox.Click += new System.EventHandler(this.Img_Click);
                    pictureBox.MouseWheel += new MouseEventHandler(this.Img_dblClick);
                    tile.Picture = pictureBox;
                    
                    xpos += tileXSize;

                    tiles.Add(tile);

                }
                ypos += tileYSize;
                xpos = 0;
            }

            return tiles;
        }

        private void Img_Click(object sender, EventArgs e)
        {
            PictureBox picture = (PictureBox)sender;
            Tile tile = (Tile)picture.Tag;
            tile.Flips = 0;
            picture.Focus();
            tile.Picture.ImageLocation = _currentType.ToString().Png();
            tile.TextureType = _currentType;
            
            //grpControls.Controls.Add(picture);
        }

        private void Img_dblClick(object sender, EventArgs e)
        {
            PictureBox picture = (PictureBox)sender;


            Image pic = picture.Image;
            pic.RotateFlip(RotateFlipType.Rotate90FlipNone);
            picture.Image = pic;

            
            
            Tile tile = (Tile)picture.Tag;
            
            
            
            tile.FlipCountAdd();
           // tile.Picture.ImageLocation = _currentType.ToString().Png();

            //grpControls.Controls.Add(picture);




        }
        public Image RandomRotate(Image item)
        {
           
            Array values = Enum.GetValues(typeof(RotateFlipType));
            
            RotateFlipType randomBar = (RotateFlipType)values.GetValue(random.Next(values.Length));
            item.RotateFlip(randomBar);


            return item;
        }

        private void btn_Save_Click(object sender, EventArgs e)
        {
            _map.Tiles = _tiles;
            string jj = _map.ToXML();

            System.IO.File.WriteAllText(@"Map.txt", jj);
        }

        private void Control_Click(object sender, EventArgs e)
        {
            //  _currentType = (MapTileType)

            _currentType = (MapTileType)((PictureBox)sender).Tag;
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            string jj = System.IO.File.ReadAllText(@"Map.txt");
            Map newMap = jj.LoadFromXMLString();

            for(int i = 0; i < newMap.Tiles.Count; i++)
            {
                newMap.Tiles[i].Picture = _tiles[i].Picture;
                Image rotate = Image.FromFile(newMap.Tiles[i].TextureType.ToString().Png());

                if (newMap.Tiles[i].Flips != 0)
                {
                    for (int f = 0; f < newMap.Tiles[i].Flips; f++)
                    {
                        rotate.RotateFlip(RotateFlipType.Rotate90FlipNone);
                    }
                }

                newMap.Tiles[i].Picture.Image = rotate;
                newMap.Tiles[i].Picture.Tag= newMap.Tiles[i];


            }





            _tiles = newMap.Tiles;
        }

        private void Grid_Click(object sender, EventArgs e)
        {
            border = !border;
            BorderStyle style;

            if (border)
                style = BorderStyle.FixedSingle;
            else
                style = BorderStyle.None;

            foreach (Tile tile in _tiles)
            {
                tile.Picture.BorderStyle = style;
            }
        }
    }

    public static class Extensions
    {


        public static string Png(this string item)
        {
            return item.ToString() + ".png";
        }

        public static string ToXML<T>(this T value)
        {
            var stringwriter = new System.IO.StringWriter();
            var serializer = new XmlSerializer(value.GetType());
            serializer.Serialize(stringwriter, value);
            return stringwriter.ToString();
        }

        public static Map LoadFromXMLString(this string xmlText)
        {
            var stringReader = new System.IO.StringReader(xmlText);
            var serializer = new XmlSerializer(typeof(Map));
            return serializer.Deserialize(stringReader) as Map;
        }


      
     
    }
}
